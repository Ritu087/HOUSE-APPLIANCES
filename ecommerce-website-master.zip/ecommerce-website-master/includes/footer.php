<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Copyright&copy;HA | All Rights Reserved | Contact Us: +91 60000 80000</b></span></div>
</footer>
    